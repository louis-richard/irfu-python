#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
.py

@author : Louis RICHARD
"""
