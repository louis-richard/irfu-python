# Contributing to pyrfu

The following is a set of guidelines for contributing to ``pyrfu`` and its packages, which are hosted in the Atom Organization on GitHub. These are mostly guidelines, not rules. Use your best judgment, and feel free to propose changes to this document in a pull request.

## Introduction

## Python version

## Coding style

## Documentation