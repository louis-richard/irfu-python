CONFIG = {"local_data_dir": "/Volumes/mms",
          'mirror_data_dir': None,  # e.g., '/Volumes/data_network/data/mms'
          'debug_mode': False,
          'download_only': False,
          'no_download': False}
