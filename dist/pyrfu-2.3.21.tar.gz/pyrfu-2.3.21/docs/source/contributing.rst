Contributing to pyrfu
========================

All contributions are welcome. For detailed information about the code style please
read the following instructions. All the code must have a adequate number of tests
that assures it's credibility. Feel free to make ``pull`` requests.

.. include:: ./../../CONTRIBUTING.rst
   :start-after: start-marker-style-do-not-remove
