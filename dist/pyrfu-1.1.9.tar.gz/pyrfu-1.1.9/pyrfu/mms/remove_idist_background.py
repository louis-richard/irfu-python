# -*- coding: utf-8 -*-
"""
remove_idist_background.py

@author : Louis RICHARD
"""

import numpy as np
import xarray as xr

from astropy import constants

from ..pyrf.ts_tensor_xyz import ts_tensor_xyz


def remove_idist_background(n_i=None, v_gse_i=None, p_gse_i=None, n_bg_i=None, p_bg_i=None):
	"""
	Removes penetrating radiation background from ion moments

	Parameters :
		n_i : DataArray
			Time series of the ion density
		v_gse_i : DataArray
			Time series of the ion bulk velocity
		p_gse_i : DataArray
			Time series of the ion pressure tensor
		n_bg_i : DataArray
			Time series of the background ion number density
		p_bg_i : DataArray
			Time series of the background ion pressure scalar

	Returns :
		n_i_new : DataArray
			Time series of the corrected ion number density
		v_gse_i_new : DataArray
			Time series of the corrected ion bulk velocity
		p_gse_i : DataArray
			Time series of the corrected ion pressure tensor
	
	References:
		MMS DIS Penetrating radiation correction methods: 
			https://lasp.colorado.edu/galaxy/display/MFDPG/Penetrating+Radiation+in+DIS+Data

	"""

	if (n_i is None) or (v_gse_i is None) or (p_gse_i is None) or (n_bg_i is None) or (p_bg_i is None):
		raise ValueError("remove_idist_background requires exactly 5 arguments")

	assert isinstance(n_i, xr.DataArray)
	assert isinstance(v_gse_i, xr.DataArray)
	assert isinstance(p_gse_i, xr.DataArray)
	assert isinstance(n_bg_i, xr.DataArray)
	assert isinstance(p_bg_i, xr.DataArray)

	m_p = constants.m_p.value

	# Number density
	n_i_new = n_i - n_bg_i.data

	# Bulk velocity
	v_gse_i_new = v_gse_i
	v_gse_i_new *= n_i / n_i_new
	
	# Pressure tensor
	p_gse_i_new_data = np.zeros(p_gse_i.shape)
	
	# P_xx_i
	p_gse_i_new_data[:, 0, 0] += p_gse_i.data[:, 0, 0]
	p_gse_i_new_data[:, 0, 0] -= p_bg_i.data
	p_gse_i_new_data[:, 0, 0] += m_p * n_i.data * v_gse_i.data[:, 0] * v_gse_i.data[:, 0]
	p_gse_i_new_data[:, 0, 0] -= m_p * n_i_new.data * v_gse_i_new.data[:, 0] * v_gse_i_new.data[:, 0]

	# P_yy_i
	p_gse_i_new_data[:, 1, 1] += p_gse_i.data[:, 1, 1]
	p_gse_i_new_data[:, 1, 1] -= p_bg_i.data
	p_gse_i_new_data[:, 1, 1] += m_p * n_i.data * v_gse_i.data[:, 1] * v_gse_i.data[:, 1]
	p_gse_i_new_data[:, 1, 1] -= m_p * n_i_new.data * v_gse_i_new.data[:, 1] * v_gse_i_new.data[:, 1]

	# P_zz_i
	p_gse_i_new_data[:, 2, 2] += p_gse_i.data[:, 2, 2]
	p_gse_i_new_data[:, 2, 2] -= p_bg_i.data
	p_gse_i_new_data[:, 2, 2] += m_p * n_i.data * v_gse_i.data[:, 2] * v_gse_i.data[:, 2]
	p_gse_i_new_data[:, 2, 2] -= m_p * n_i_new.data * v_gse_i_new.data[:, 2] * v_gse_i_new.data[:, 2]

	# P_xy_i & P_yx_i
	p_gse_i_new_data[:, 0, 1] += p_gse_i.data[:, 0, 1]
	p_gse_i_new_data[:, 0, 1] += m_p * n_i.data * v_gse_i.data[:, 0] * v_gse_i.data[:, 1]
	p_gse_i_new_data[:, 0, 1] -= m_p * n_i_new.data * v_gse_i_new.data[:, 0] * v_gse_i_new.data[:, 1]
	p_gse_i_new_data[:, 1, 0] = p_gse_i_new_data[:, 0, 1]

	# P_xz_i & P_zx_i
	p_gse_i_new_data[:, 0, 2] += p_gse_i.data[:, 0, 2]
	p_gse_i_new_data[:, 0, 2] += m_p * n_i.data*v_gse_i.data[:, 0] * v_gse_i.data[:, 2]
	p_gse_i_new_data[:, 0, 2] -= m_p * n_i_new.data * v_gse_i_new.data[:, 0] * v_gse_i_new.data[:, 2]
	p_gse_i_new_data[:, 2, 0] = p_gse_i_new_data[:, 0, 2]

	# P_yz_i & P_zy_i
	p_gse_i_new_data[:, 1, 2] += p_gse_i.data[:, 1, 2]
	p_gse_i_new_data[:, 1, 2] += m_p * n_i.data * v_gse_i.data[:, 1] * v_gse_i.data[:, 2]
	p_gse_i_new_data[:, 1, 2] -= m_p * n_i_new.data * v_gse_i_new.data[:, 1] * v_gse_i_new.data[:, 2]
	p_gse_i_new_data[:, 2, 1] = p_gse_i_new_data[:, 1, 2]

	p_gse_i_new = ts_tensor_xyz(p_gse_i.time.data, p_gse_i_new_data)
	
	return n_i_new, v_gse_i_new, p_gse_i_new
