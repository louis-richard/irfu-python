.. pyrfu documentation master file, created by
   sphinx-quickstart on Thu Nov 26 15:54:25 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pyrfu's documentation!
=================================

.. include:: ../../README.rst
   :end-before: end-marker-intro-do-not-remove


.. toctree::
   :maxdepth: 1
   :caption: Contents:

   getting_started
   modules
   examples
   contributing


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
