#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Built-in import
import re
import pdb
import warnings

# 3rd party imports
import numpy as np

from cdflib import CDF, cdfepoch

# Local imports
from ..pyrf import (
    ts_skymap,
    iso86012datetime64,
    datetime642ttns,
    cdfepoch2datetime64,
    extend_tint,
    time_clip,
)

__author__ = "Louis Richard"
__email__ = "louisr@irfu.se"
__copyright__ = "Copyright 2020-2023"
__license__ = "MIT"
__version__ = "2.3.26"
__status__ = "Prototype"

# Keys of the global attributes to keep from CDF informations
Globkeys = ["CDF", "Version", "Encoding", "Checksum", "Compressed", "LeapSecondUpdated"]


def _shift_epochs(file, epoch):
    r"""Shift times for particles."""

    epoch_shifted = epoch["data"].copy()

    try:
        delta_minus_var = {
            "data": file.varget(epoch["attrs"]["DELTA_MINUS_VAR"]),
            "attrs": file.varget(epoch["attrs"]["DELTA_MINUS_VAR"]),
        }
        delta_plus_var = {
            "data": file.varget(epoch["attrs"]["DELTA_PLUS_VAR"]),
            "attrs": file.varget(epoch["attrs"]["DELTA_PLUS_VAR"]),
        }

        delta_vars = [delta_minus_var, delta_plus_var]
        flags_vars = [1e3, 1e3]  # Time scaling conversion flags

        for i, delta_var in enumerate(delta_vars):
            if isinstance(delta_var["attrs"], dict) and "UNITS" in delta_var["attrs"]:
                if delta_var["attrs"]["UNITS"].lower() == "s":
                    flags_vars[i] = 1e3
                elif delta_var["attrs"]["UNITS"].lower() == "ms":
                    flags_vars[i] = 1e0
                else:
                    message = " units are not clear, assume s"
                    warnings.warn(message)
            else:
                message = "Epoch_plus_var/Epoch_minus_var units are not clear, assume s"
                warnings.warn(message)

        flag_minus, flag_plus = flags_vars
        t_offset = (
            delta_plus_var["data"] * flag_plus - delta_minus_var["data"] * flag_minus
        )
        t_offset = np.timedelta64(int(np.round(t_offset, 1) * 1e6 / 2), "ns")
        t_diff = (
            delta_plus_var["data"] * flag_plus - delta_minus_var["data"] * flag_minus
        )
        t_diff = np.timedelta64(int(np.round(t_diff, 1) * 1e6 / 2), "ns")
        t_diff_data = np.median(np.diff(epoch["data"])) / 2

        if t_diff_data != np.mean(t_diff):
            t_offset = t_diff_data

        epoch_shifted += t_offset

        return {"data": epoch_shifted, "attrs": epoch["attrs"]}

    except KeyError:
        return {"data": epoch_shifted, "attrs": epoch["attrs"]}


def _get_epochs(file, cdf_name, tint):
    r"""Get epochs form cdf and shift if needed."""

    depend0_key = file.varattsget(cdf_name)["DEPEND_0"]

    out = {"data": file.varget(depend0_key, starttime=tint[0], endtime=tint[1])}

    if file.varinq(depend0_key)["Data_Type_Description"] == "CDF_TIME_TT2000":
        try:
            out["data"] = cdfepoch2datetime64(out["data"])
        except TypeError:
            pass

    # Get epoch attributes
    out["attrs"] = file.varattsget(depend0_key)

    # Shift times if particle data
    is_part = re.search("^mms[1-4]_d[ei]s_", cdf_name)  # Is it FPI data?
    is_part = is_part or re.search("^mms[1-4]_hpca_", cdf_name)  # Is it HPCA data?

    if is_part:
        out = _shift_epochs(file, out)

    return out


def get_dist(file_path, cdf_name, tint):
    r"""Read field named cdf_name in file and convert to velocity distribution
    function.

    Parameters
    ----------
    file_path : str
        Path of the cdf file.
    cdf_name : str
        Name of the target variable in the cdf file.
    tint : list of str
        Time interval.

    Returns
    -------
    out : xarray.Dataset
        Time series of the velocity distribution function if the target
        specie in the selected time interval.

    """

    tmmode = cdf_name.split("_")[-1]

    if "_dis_" in cdf_name:
        specie = "ions"
    elif "_des_" in cdf_name:
        specie = "electrons"
    else:
        raise AttributeError("Couldn't get the particle species from file name!!")

    tint_org = tint
    tint = extend_tint(tint, [-1, 1])
    tint = list(datetime642ttns(iso86012datetime64(np.array(tint))))

    with CDF(file_path) as file:
        # Get the relevant CDF file information and add the global attributes
        glob_attrs = {k: file.cdf_info()[k] for k in Globkeys}
        glob_attrs = {**glob_attrs, **file.globalattsget()}
        glob_attrs = {**glob_attrs, **{"tmmode": tmmode, "species": specie}}

        # Get VDF zVariable attributes and sort them
        dist_attrs = file.varattsget(cdf_name)
        dist_attrs = {k: dist_attrs[k] for k in sorted(dist_attrs)}

        # Get CDF keys to Epoch, energy, azimuthal and elevation angle zVariables
        depends_keys = [dist_attrs[f"DEPEND_{i:d}"] for i in range(4)]
        depend0_key, depend1_key, depend2_key, depend3_key = depends_keys

        # Get coordinates attributes and sort them
        coords_attrs = [file.varattsget(k) for k in depends_keys]
        coords_attrs = [{k: attrs[k] for k in sorted(attrs)} for attrs in coords_attrs]
        coords_names = ["time", "phi", "theta", "energy"]
        coords_attrs = {k: attrs for k, attrs in zip(coords_names, coords_attrs)}

        times = _get_epochs(file, cdf_name, tint)
        times = times["data"]

        dist = file.varget(cdf_name, starttime=tint[0], endtime=tint[1])
        dist = np.transpose(dist, [0, 3, 1, 2])
        phi = file.varget(depend1_key, starttime=tint[0], endtime=tint[1])
        theta = file.varget(depend2_key)
        energy = file.varget(depend3_key, starttime=tint[0], endtime=tint[1])

        if tmmode == "brst":
            en0_name = "_".join(
                [
                    cdf_name.split("_")[0],
                    cdf_name.split("_")[1],
                    "energy0",
                    cdf_name.split("_")[-1],
                ]
            )
            en1_name = "_".join(
                [
                    cdf_name.split("_")[0],
                    cdf_name.split("_")[1],
                    "energy1",
                    cdf_name.split("_")[-1],
                ]
            )

            e_step_table_name = "_".join(
                [
                    cdf_name.split("_")[0],
                    cdf_name.split("_")[1],
                    "steptable_parity",
                    cdf_name.split("_")[-1],
                ]
            )

            step_table = file.varget(
                e_step_table_name, starttime=tint[0], endtime=tint[1]
            )

            if en0_name not in file.cdf_info()["zVariables"]:
                if energy.ndim == 1:
                    energy0 = energy
                    energy1 = energy
                elif energy.shape[0] == 1:
                    energy0 = energy[0, :]
                    energy1 = energy[0, :]
                else:
                    energy0 = energy[1, :]
                    energy1 = energy[0, :]
            else:
                energy0 = file.varget(en0_name)
                energy1 = file.varget(en1_name)

            # Overwrite energy to make sure that energy0 and energy1 are used instead
            energy = None

        elif tmmode == "fast":
            if energy.ndim == 1:
                energy0 = energy
                energy1 = energy
            elif energy.shape[0] == 1:
                energy0 = energy[0, :]
                energy1 = energy[0, :]
            else:
                energy0 = energy[1, :]
                energy1 = energy[0, :]

            step_table = np.zeros(len(times))

        else:
            raise ValueError("Invalid sampling mode!!")

        d_en_name = "_".join(
            [
                cdf_name.split("_")[0],
                cdf_name.split("_")[1],
                "energy_delta",
                cdf_name.split("_")[-1],
            ]
        )

        if d_en_name in file.cdf_info()["zVariables"]:
            glob_attrs["delta_energy_plus"] = file.varget(
                d_en_name, starttime=tint[0], endtime=tint[1]
            )
            glob_attrs["delta_energy_minus"] = file.varget(
                d_en_name, starttime=tint[0], endtime=tint[1]
            )
        else:
            glob_attrs["delta_energy_plus"] = None
            glob_attrs["delta_energy_minus"] = None

        # Sort the global attributes
        glob_attrs = {k: glob_attrs[k] for k in sorted(glob_attrs)}

        out = ts_skymap(
            times,
            dist,
            energy,
            phi,
            theta,
            energy0=energy0,
            energy1=energy1,
            esteptable=step_table,
            attrs=dist_attrs,
            coords_attrs=coords_attrs,
            glob_attrs=glob_attrs,
        )

    out = time_clip(out, tint_org)

    return out
