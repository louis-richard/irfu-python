install :
pip install --index-url https://test.pypi.org/project/ --no-deps pyrf 