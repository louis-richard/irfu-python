Getting started
===============

Installation
------------

.. include:: ../../README.rst
   :start-after: start-marker-install-do-not-remove
   :end-before: end-marker-install-do-not-remove

