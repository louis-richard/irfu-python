import os

CONFIG = {"local_data_dir": "/Volumes/mms",
         #'local_data_dir': '/Users/louis/data/mms', # example of setting your local data directory on macOS
         #'local_data_dir': 'c:\users\louis\data\mms', # and Windows
          'mirror_data_dir': None, # e.g., '/Volumes/data_network/data/mms'
          'debug_mode': False,
          'download_only': False,
          'no_download': False}